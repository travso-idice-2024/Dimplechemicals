import React from "react";

const ViewUserModal = ({ setViewModalOpen }) => {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white w-[500px] pt-0 pb-4 rounded-[6px] flex flex-col">
        <h2 className="text-white text-[20px] font-poppins mb-2 px-0 py-2 text-center bg-bgDataNew rounded-t-[5px]">
          Employee Details
        </h2>
        <div className="mt-5 md:mt-6 px-6 flex flex-col gap-2 overflow-y-auto h-[400px]">
          <Detail label="Name" value="Prashant Mishra" />
          <Detail label="Email" value="prashant@example.com" />
          <Detail label="Status" value="Active" />
          <Detail label="Role" value="Software Engineer" />
          <Detail label="Gender" value="Male" />
          <Detail label="Phone" value="9876543210" />
          <Detail label="Department" value="IT" />
          <Detail label="City" value="Mumbai" />
          <Detail label="State" value="Maharashtra" />
          <Detail label="Country" value="India" />
          <Detail label="Zip Code" value="400001" />
          <Detail label="Profile Picture" value="https://via.placeholder.com/100" isImage />
          <Detail label="Leave Balance" value="15" />
          <Detail label="Basic Salary" value="₹50,000" />
          <Detail label="Bank Account" value="123456789012" />
          <Detail label="IFSC Code" value="HDFC0001234" />
          <Detail label="Address" value="123, Andheri West, Mumbai" />
          <Detail label="Aadhar No." value="1234-5678-9012" />
          <Detail label="PAN No." value="ABCDE1234F" />
          <Detail label="Offer Letter Date" value="2023-01-10" />
          <Detail label="Joining Date" value="2023-02-01" />
          <Detail label="Exit Date" value="-" />
          <Detail label="Employment Type" value="Full-Time" />
          <Detail label="Reporting Manager ID" value="2" />
          <Detail label="Work Location" value="Mumbai Office" />
        </div>
        <div className="flex items-end justify-end gap-2 px-6">
            <button
              className="mt-4 bg-gray-500 text-white px-3 py-2 rounded hover:bg-gray-600"
              onClick={() => setViewModalOpen(false)}
            >
              Close
            </button>
          </div>
      </div>
    </div>
  );
};

// Reusable component for displaying details
const Detail = ({ label, value, isImage }) => (
  <div className="flex items-center gap-3">
    <label className="font-poppins font-semibold text-[18px] text-bgData">
      {label}
    </label>
    <p className="font-poppins font-semibold text-[18px]">:</p>
    {isImage ? (
      <img src={value} alt={label} className="w-12 h-12 rounded-full" />
    ) : (
      <p>{value}</p>
    )}
    </div>
);

export default ViewUserModal;
