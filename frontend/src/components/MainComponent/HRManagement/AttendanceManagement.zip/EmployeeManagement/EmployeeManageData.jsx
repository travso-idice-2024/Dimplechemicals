import React, { useState, useEffect } from "react";
import "./EmployeeManageData.css";
import { iconsImgs } from "../../../../utils/images";
import EmployeeTable from "./EmployeeTable";
import Pagination from "./Pagination";
import AddRoleModal from "./AddRoleModal";
import ViewUserModal from "./ViewUserModal";
import EditUserModal from "./EditUserModal";

const EmployeeManageData = () => {
  const [searchTerm, setSearchTerm] = useState("");
   // Load initial users from localStorage or use default list
    const [users, setUsers] = useState(() => {
      const storedUsers = localStorage.getItem("employeeusers");
      return storedUsers ? JSON.parse(storedUsers) : [
        {
          id: 1,
          name: "Prashant Mishra",
          email: "prashant@example.com",
          status: "Active",
          password: "password123",
          role: "Software Engineer",
          gender: "Male",
          phone: "9876543210",
          department: "IT",
          city: "Mumbai",
          state: "Maharashtra",
          country: "India",
          zipCode: "400001",
          profilePicture: "https://via.placeholder.com/100",
          leaveBalance: 15,
          basicSalary: 50000,
          bankAccountNumber: "123456789012",
          ifscCode: "HDFC0001234",
          address: "123, Andheri West, Mumbai",
          aadharNo: "1234-5678-9012",
          panNo: "ABCDE1234F",
          offerLetterDate: "2023-01-10",
          joiningDate: "2023-02-01",
          exitDate: null,
          employmentType: "Full-Time",
          reportingManagerId: 2,
          workLocation: "Mumbai Office",
        },
        {
          id: 2,
          name: "Amit Verma",
          email: "amit@example.com",
          status: "Active",
          password: "amitpass",
          role: "HR Manager",
          gender: "Male",
          phone: "9856473210",
          department: "HR",
          city: "Delhi",
          state: "Delhi",
          country: "India",
          zipCode: "110001",
          profilePicture: "https://via.placeholder.com/100",
          leaveBalance: 20,
          basicSalary: 60000,
          bankAccountNumber: "987654321098",
          ifscCode: "ICIC0005678",
          address: "45, Connaught Place, Delhi",
          aadharNo: "2345-6789-0123",
          panNo: "XYZAB9876C",
          offerLetterDate: "2022-06-15",
          joiningDate: "2022-07-01",
          exitDate: null,
          employmentType: "Full-Time",
          reportingManagerId: 3,
          workLocation: "Delhi Office",
        },
        {
          id: 3,
          name: "Sneha Sharma",
          email: "sneha@example.com",
          status: "Inactive",
          password: "snehapass",
          role: "Finance Executive",
          gender: "Female",
          phone: "9543217890",
          department: "Finance",
          city: "Bangalore",
          state: "Karnataka",
          country: "India",
          zipCode: "560001",
          profilePicture: "https://via.placeholder.com/100",
          leaveBalance: 10,
          basicSalary: 45000,
          bankAccountNumber: "112233445566",
          ifscCode: "SBI0001122",
          address: "78, MG Road, Bangalore",
          aadharNo: "3456-7890-1234",
          panNo: "PQRCD5678L",
          offerLetterDate: "2021-03-20",
          joiningDate: "2021-04-05",
          exitDate: "2024-01-10",
          employmentType: "Contract",
          reportingManagerId: 1,
          workLocation: "Bangalore Office",
        }
    ]});

  const [isAddUserModalOpen, setAddUserModalOpen] = useState(false);
  const [isViewModalOpen, setViewModalOpen] = useState(false);
  const [isEditUserModalOpen, setEditUserModalOpen] = useState(false);
  const usersPerPage = 8;
  const totalPages = Math.ceil(users.length / usersPerPage);

   // Load currentPage from sessionStorage or default to page 1
   const [currentPage, setCurrentPage] = useState(() => {
    return parseInt(sessionStorage.getItem("currentPage")) || 1;
  });

  // Save currentPage to sessionStorage when it changes
  useEffect(() => {
    sessionStorage.setItem("currentPage", currentPage);
  }, [currentPage]);

  // Save users to localStorage whenever users state updates
  useEffect(() => {
    localStorage.setItem("employeeusers", JSON.stringify(users));
  }, [users]);


  
  

  // Handle page change
  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  // Filtered user list based on search
  const filteredUsers = users
    .sort((a, b) => b.name.localeCompare(a.name))
    .filter(
      (user) =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

  // Paginate user data
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

  


  return (
    <div className="main-content-holder max-h-[615px] overflow-y-auto scrollbar-hide">
      <div className="flex flex-col gap-[20px]">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-white text-[20px] font-semibold">
              Employee Management
            </h1>
          </div>
          <div className="flex items-center gap-[5px]">
            <div>
              <input
                type="search"
                className="relative m-0 block w-full min-w-0 flex-auto rounded border border-solid border-[#473b33] bg-transparent bg-clip-padding px-3 py-[0.25rem] text-base font-normal leading-[1.6] text-white outline-none transition duration-200 ease-in-out focus:z-[3] focus:border-[#473b33] focus:text-white focus:shadow-[#473b33] focus:outline-none dark:border-[#473b33] dark:text-white dark:placeholder:text-white dark:focus:border-[#473b33]"
                placeholder="Search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <button
                className="flex items-center text-white bg-[#fe6c00] rounded-[3px] px-3 py-[0.28rem]"
                onClick={() => setAddUserModalOpen(true)}
              >
                <img
                  src={iconsImgs.plus}
                  alt="plus icon"
                  className="w-[18px] mr-1"
                />{" "}
                Add Employee
              </button>
            </div>
          </div>
        </div>
        <div className="bg-bgData rounded-[8px] shadow-md shadow-black/5 text-white px-4 py-6">
          {/*------- Table Data Start -------*/}
          <EmployeeTable
            setEditUserModalOpen={setEditUserModalOpen}
            currentUsers={currentUsers}
            setViewModalOpen={setViewModalOpen}
            currentPage={currentPage}
            usersPerPage={usersPerPage}
          />
          {/*------- Table Data End -------*/}
        </div>
        {/* Pagination Controls with Number */}
        <Pagination
          currentPage={currentPage}
          handlePageChange={handlePageChange}
          totalPages={totalPages}
        />
      </div>

      {/* Add User Modal */}
      {isAddUserModalOpen && (
        <AddRoleModal
          setAddUserModalOpen={setAddUserModalOpen}
        />
      )}

      {/* Edit User Modal */}
      {isEditUserModalOpen && (
        <EditUserModal
          setEditUserModalOpen={setEditUserModalOpen}
        />
      )}

      {/* View User Modal */}
      {isViewModalOpen && (
        <ViewUserModal
          setViewModalOpen={setViewModalOpen}
        />
      )}
    </div>
  );
};

export default EmployeeManageData;
