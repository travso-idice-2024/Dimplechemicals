const express = require('express');
const { register, login ,listUsers} = require('../controllers/auth.controller');
const {listRoles, addRole, removeRole, updateRole} = require('../controllers/role.controller');

const authMiddleware = require('../middlewares/auth.middleware');


const router = express.Router();

// User Registration Route
router.post('/register', register);

// User Login Route
router.post('/login', login);

//user list
router.get("/userList",authMiddleware, listUsers);


//role routes
router.get("/roleList", authMiddleware, listRoles);
router.post("/addRole", authMiddleware, addRole);
router.put("/updateRole/:id", authMiddleware, updateRole);  // Pass `id` in the URL
router.delete("/removeRole/:id", authMiddleware, removeRole);  // Pass `id` in the URL


module.exports = router;
