
const { CheckinCheckout,User } = require("../models");
const { Op } = require("sequelize");

const checkIn = async (req, res) => {
    try {
      const { emp_id, latitude, longitude,checkin_location, data } = req.body;
  
      // Insert check-in details
      const checkInRecord = await CheckinCheckout.create({
        emp_id,
        latitude,
        longitude,
        checkin_location,
        check_in_time: new Date(),
        data,
      });
  
      res.status(201).json({ message: "Check-in successful!", checkInRecord });
    } catch (error) {
      console.error("Check-in error:", error);
      res.status(500).json({ error: "Database error" });
    }
  };

//   const checkOut = async (req, res) => {
//     try {
//       const { emp_id } = req.params;
//       const checkOutTime = new Date();
  
//       // Find the latest check-in record without a check-out time
//       const checkInRecord = await CheckinCheckout.findOne({
//         where: { emp_id, check_out_time: null },
//         order: [["check_in_time", "DESC"]],
//       });
  
//       if (!checkInRecord) {
//         return res.status(404).json({ error: "No active check-in found" });
//       }
  
//       // Calculate working hours
//       const checkInTime = new Date(checkInRecord.check_in_time);
//       const hoursWorked = (checkOutTime - checkInTime) / (1000 * 60 * 60); // Convert ms to hours
  
//       // Update check-out details
//       await checkInRecord.update({
//         check_out_time: checkOutTime,
//         working_hours: hoursWorked.toFixed(2),
//       });
  
//       res.json({ message: "Check-out successful!", checkInRecord });
//     } catch (error) {
//       console.error("Check-out error:", error);
//       res.status(500).json({ error: "Database error" });
//     }
//   };
  
const checkOut = async (req, res) => {
    try {
      const { id } = req.params; // ✅ Get check-in record ID
      const { checkout_location, data } = req.body; // ✅ Get new data from request
      const checkOutTime = new Date();
  
      // Find the check-in record using `id`
      const checkInRecord = await CheckinCheckout.findByPk(id);
  
      if (!checkInRecord) {
        return res.status(404).json({ error: "Check-in record not found" });
      }
  
      // Ensure this record hasn't been checked out already
      if (checkInRecord.check_out_time) {
        return res.status(400).json({ error: "Already checked out" });
      }
  
      // Calculate working hours
      const checkInTime = new Date(checkInRecord.check_in_time);
      const hoursWorked = (checkOutTime - checkInTime) / (1000 * 60 * 60); // Convert ms to hours
  
      // Update check-out details
      await checkInRecord.update({
        check_out_time: checkOutTime,
        working_hours: hoursWorked.toFixed(2),
        checkout_location, // ✅ Store checkout location
        data, // ✅ Update additional data
      });
  
      res.json({ message: "Check-out successful!", checkInRecord });
    } catch (error) {
      console.error("Check-out error:", error);
      res.status(500).json({ error: "Database error" });
    }
  };

  const getCheckinCheckoutReport = async (req, res) => {
    try {
      const { month, emp_id } = req.query;
      let whereClause = {};
  
      // If emp_id is provided, filter by employee ID
      if (emp_id) {
        const employee = await User.findByPk(emp_id);
        if (!employee) {
          return res.status(404).json({ message: "Employee not found" });
        }
        whereClause.emp_id = emp_id;
      }
  
      // If month is provided, filter by the current year's month
      if (month) {
        const currentYear = new Date().getFullYear();
        const startDate = new Date(`${currentYear}-${month}-01T00:00:00.000Z`);
        const endDate = new Date(startDate);
        endDate.setMonth(endDate.getMonth() + 1);
  
        whereClause.check_in_time = { [Op.between]: [startDate, endDate] };
      }
  
      // Fetch records along with fullname from Users table
      const records = await CheckinCheckout.findAll({
        where: whereClause,
        include: [
          {
            model: User,
            attributes: ["fullname"], // ✅ Fetch only fullname
            required: true, // Ensures only records with matching users are returned
          },
        ],
        order: [["check_in_time", "ASC"]],
      });
  
      return res.status(200).json({
        message: "Check-in/Check-out report fetched successfully",
        records,
      });
    } catch (error) {
      console.error("Report fetch error:", error);
      return res.status(500).json({ message: "Server error", error });
    }
  };

  module.exports = { checkIn, checkOut, getCheckinCheckoutReport };
